# test_bitjson

testthat::context('mappings and predicates')

testthat::test_that('mapping preserves data integrity', {
  
  # mapped still identical
  testthat::expect_identical(fromBitJSON(toBitJSON(datasets::iris)), 
                             datasets::iris)
  testthat::expect_identical(fromBitJSON(toBitJSON(datasets::islands)), 
                             datasets::islands)
  
})

testthat::test_that('predicate functions work', {
  
  # setup
  valid.bits <- toBitJSON(419L)
  invalid.bits <- '[0,1,0,0,"0",1,0,1]'
  nclosed.bits <- paste0('{"acab":', toBitJSON(1L), ',"haha":[419]}')
##multi <- paste0('[', 
##                toBitJSON(2L, compress=FALSE), ',', 
##                jsonlite::toJSON(99999L), ',', 
##                toBitJSON(419L), 
##                ']')
  
  # match
  testthat::expect_identical(isBitJSON(valid.bits), 
                             TRUE)
  
  # nomatch
  testthat::expect_identical(isBitJSON(invalid.bits), 
                             FALSE)
  testthat::expect_identical(isBitJSON(nclosed.bits), 
                             FALSE)
  testthat::expect_identical(isBitJSON('[0,1,2,3,4]'), 
                             FALSE)
  
### contains
##testthat::expect_identical(containsBitJSON(nclosed.bits), 
##                           TRUE)
##testthat::expect_identical(containsBitJSON(multi), 
##                           TRUE)
  
### extract
##testthat::expect_identical(isBitJSON(extractBitJSON(nclosed.bits)), 
##                           TRUE)
##testthat::expect_identical(sapply(extractBitJSON(multi), 
##                                  isBitJSON,
##                                  USE.NAMES=FALSE), 
##                           c(TRUE, TRUE))
  
})