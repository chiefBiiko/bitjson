library(testthat)
library(bitjson)

test_check("bitjson")
