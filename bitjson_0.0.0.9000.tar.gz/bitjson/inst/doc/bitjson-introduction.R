## ----setup, include=FALSE------------------------------------------------
knitr::opts_chunk$set(comment=NA)

## ------------------------------------------------------------------------
# marshal to bit JSON
nilebits <- bitjson::toBitJSON(datasets::Nile)

# unmarshal from bit JSON
nile <- bitjson::fromBitJSON(nilebits)

# marshaled still consistent
cat('consistent:', identical(datasets::Nile, nile))

## ------------------------------------------------------------------------
# write to disk
bitjson::toBitJSON(datasets::islands, file='islands.json')

# read from disk
inlands <- bitjson::fromBitJSON('islands.json')

# after io roundtrip
cat('consistent via disk:', identical(datasets::islands, inlands))

## ------------------------------------------------------------------------
# just a demo - do use compression 
xl <- bitjson::toBitJSON(419L, compress=FALSE)

# uncompressed xl bit JSON array
cat('uncompressed:\n', xl, sep='')

## ------------------------------------------------------------------------
# parameter compress defaults to TRUE
xs <- bitjson::toBitJSON(419L)

# compressed bit JSON array
cat('compressed:\n', xs, sep='')

